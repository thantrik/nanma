function setScreenshotUrl(url) {
  document.getElementById("target").src = url;
}
